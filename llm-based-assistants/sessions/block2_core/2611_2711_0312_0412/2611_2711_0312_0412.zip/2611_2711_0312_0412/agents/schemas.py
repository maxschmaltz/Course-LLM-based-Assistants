from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any


# schemas for the planning stage
# TODO
class PlanItem(BaseModel):
    pass
    
class Plan(BaseModel):
    pass

class PlanGrading(BaseModel):
    pass